package com.example.biblioteca.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Libro {

    private int id;
    private String titulo;
    private String isbn;
    private String autor;
    private String editorial;
    private String fechaPublicacion;

}